# Vodacom SNI Scanner (Android)

A native Android diagnostics app targeting Android 8.0+ (API 26+) and Android 15/API 35 compile target.

## Included
- DNS resolution and returned IP addresses
- TCP reachability checks
- TLS handshake with explicit SNI and Android certificate validation
- HTTPS GET status code
- SSH TCP/banner check (no credentials)
- HTTP CONNECT proxy handshake check
- SOCKS5 greeting/auth-method negotiation check
- WebSocket upgrade handshake check
- Local WireGuard/OpenVPN profile structure validation (profile content is not printed or uploaded)
- Network transport indicator

## Important limitations
- This is a diagnostics app, not a free-internet or carrier-billing bypass tool.
- A successful DNS/TCP/TLS/HTTP test does not prove that a domain is zero-rated.
- SSH, HTTP CONNECT, SOCKS5 and WebSocket checks test a server the user supplies; they do not create a tunnel by themselves.
- WireGuard/OpenVPN profiles are only validated locally. Actual VPN connection requires the official WireGuard or OpenVPN client. This build does not embed either VPN engine.
- Use only servers, proxies and VPN profiles you own or are authorised to use.

## Build APK
Requires Android Studio or Android SDK + Gradle 8.9+ and JDK 17+.
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

No signing keys, credentials, proxy endpoints or VPN profiles are included.
