package za.co.vodacomsniscanner;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import javax.net.ssl.*;
import javax.net.ssl.SNIHostName;
import java.security.cert.Certificate;

public class MainActivity extends Activity {
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private EditText hostField, portField, proxyHostField, proxyPortField;
    private TextView output, networkInfo;
    private static final int PICK_CONFIG = 44;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        showNetwork();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF172033); if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5)); return t;
    }
    private EditText edit(String hint, String value, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint);
        e.setInputType(type); e.setTextSize(15); e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF9AA4B2)); return e;
    }
    private Button button(String label, Runnable r) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28)); root.setBackgroundColor(0xFFF4F6FA);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("VODACOM SNI SCANNER", 23, true); title.setTextColor(0xFFB00020); root.addView(title);
        root.addView(text("Network diagnostics • TLS • Proxy • VPN profile checks", 13, false));
        networkInfo = text("Checking network…", 13, true); root.addView(networkInfo);
        root.addView(text("HOST TEST", 16, true));
        hostField = edit("Hostname (without https://)", "connectu.vodacom.co.za", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI); root.addView(hostField);
        portField = edit("Port", "443", InputType.TYPE_CLASS_NUMBER); root.addView(portField);
        root.addView(button("Run DNS + TCP + TLS/SNI + HTTP test", () -> runHostTest()));
        root.addView(text("TUNNEL DIAGNOSTICS", 16, true));
        root.addView(text("These checks test protocol handshakes to a proxy/server you are authorised to use. They do not create a free-data tunnel.", 12, false));
        proxyHostField = edit("Your proxy/server hostname", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI); root.addView(proxyHostField);
        proxyPortField = edit("Proxy/server port", "", InputType.TYPE_CLASS_NUMBER); root.addView(proxyPortField);
        root.addView(button("Test SSH (port reachability + banner)", () -> runTask("SSH", () -> testSsh())));
        root.addView(button("Test HTTP CONNECT proxy", () -> runTask("HTTP CONNECT", () -> testConnect())));
        root.addView(button("Test SOCKS5 proxy", () -> runTask("SOCKS5", () -> testSocks5())));
        root.addView(button("Test WebSocket upgrade", () -> runTask("WebSocket", () -> testWebSocket())));
        root.addView(button("Import / validate VPN profile", () -> pickConfig()));
        root.addView(text("WireGuard and OpenVPN profiles are validated locally. This diagnostic build does not establish a VPN tunnel; use the official WireGuard/OpenVPN client to connect.", 12, false));
        root.addView(text("RESULTS", 16, true));
        output = text("Ready. Enter a hostname and run a test. Results are diagnostic only; a successful TLS handshake does not prove zero-rating.", 13, false);
        output.setBackgroundColor(0xFFFFFFFF); output.setPadding(dp(12), dp(12), dp(12), dp(12)); root.addView(output);
        root.addView(button("Clear results", () -> output.setText("Ready.")));
    }
    private void showNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            String s = "Network: unavailable";
            if (nc != null) s = "Network: " + (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "Mobile data" : nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi" : "Other connection");
            networkInfo.setText(s + " • Carrier detection depends on Android/SIM permissions");
        } catch (Exception e) { networkInfo.setText("Network status unavailable"); }
    }
    private String host() { return hostField.getText().toString().trim(); }
    private int port(EditText e, int fallback) { try { return Integer.parseInt(e.getText().toString().trim()); } catch(Exception x) { return fallback; } }
    private void log(String s) { runOnUiThread(() -> output.append("\n\n" + s)); }
    private void runTask(String name, Callable<String> c) {
        String h = proxyHostField.getText().toString().trim();
        if (h.isEmpty()) { output.setText("Enter your authorised proxy/server hostname first."); return; }
        output.setText(name + ": testing…");
        pool.submit(() -> { try { log(c.call()); } catch(Exception e) { log("ERROR: " + e.getClass().getSimpleName() + ": " + e.getMessage()); } });
    }
    private void runHostTest() {
        final String h = host(); final int p = port(portField, 443);
        if (h.isEmpty() || h.contains("/")) { output.setText("Enter a hostname only, for example example.com"); return; }
        output.setText("Testing " + h + ":" + p + "…");
        pool.submit(() -> {
            StringBuilder r = new StringBuilder();
            try {
                long t = System.currentTimeMillis(); InetAddress[] a = InetAddress.getAllByName(h);
                r.append("DNS: OK ( ").append(System.currentTimeMillis()-t).append(" ms )\n");
                for (InetAddress ip : a) r.append("  ").append(ip.getHostAddress()).append("\n");
            } catch(Exception e) { r.append("DNS: FAILED — ").append(e.getMessage()).append("\n"); }
            try (Socket s = new Socket()) {
                long t = System.currentTimeMillis(); s.connect(new InetSocketAddress(h,p),7000);
                r.append("TCP ").append(p).append(": OPEN ( ").append(System.currentTimeMillis()-t).append(" ms )\n");
            } catch(Exception e) { r.append("TCP: FAILED — ").append(e.getMessage()).append("\n"); }
            try {
                long t = System.currentTimeMillis(); SSLSocketFactory f = (SSLSocketFactory)SSLSocketFactory.getDefault();
                try (SSLSocket s = (SSLSocket)f.createSocket()) {
                    s.connect(new InetSocketAddress(h,p),7000); SSLParameters params=s.getSSLParameters();
                    params.setServerNames(java.util.Collections.singletonList(new SNIHostName(h))); s.setSSLParameters(params);
                    s.setSoTimeout(7000); s.startHandshake();
                    r.append("TLS/SNI: SUCCESS ( ").append(System.currentTimeMillis()-t).append(" ms )\n");
                    r.append("Protocol: ").append(s.getSession().getProtocol()).append("\nCipher: ").append(s.getSession().getCipherSuite()).append("\n");
                    Certificate[] certs=s.getSession().getPeerCertificates(); if(certs.length>0) r.append("Certificate: ").append(certs[0].getType()).append(" (validated by Android trust store)\n");
                }
            } catch(Exception e) { r.append("TLS/SNI: FAILED — ").append(e.getMessage()).append("\n"); }
            try {
                URL u = new URL("https://"+h+ (p==443?"":":"+p) + "/");
                HttpsURLConnection c=(HttpsURLConnection)u.openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setRequestMethod("GET");
                int code=c.getResponseCode(); r.append("HTTPS: HTTP ").append(code).append(" ").append(c.getResponseMessage()).append("\n"); c.disconnect();
            } catch(Exception e) { r.append("HTTPS: FAILED — ").append(e.getMessage()).append("\n"); }
            r.append("\nNote: reachable/TLS-successful does NOT mean zero-rated or free."); log(r.toString());
        });
    }
    private String proxyHost() { return proxyHostField.getText().toString().trim(); }
    private int proxyPort() { return port(proxyPortField, 443); }
    private Socket proxySocket() throws Exception { Socket s=new Socket(); s.connect(new InetSocketAddress(proxyHost(),proxyPort()),7000); s.setSoTimeout(7000); return s; }
    private String testSsh() throws Exception {
        try(Socket s=proxySocket()) { s.setSoTimeout(3000); BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.US_ASCII));
            s.setSoTimeout(1800); String banner; try { banner=in.readLine(); } catch(Exception e) { banner="No SSH banner received before timeout"; }
            return "TCP: reachable\nSSH banner: "+banner+"\nThis checks reachability/banner only; no credentials were sent."; }
    }
    private String testConnect() throws Exception {
        try(Socket s=proxySocket()) { String req="CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\nProxy-Connection: keep-alive\r\n\r\n";
            s.getOutputStream().write(req.getBytes(StandardCharsets.US_ASCII)); s.getOutputStream().flush();
            BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.US_ASCII)); String line=in.readLine();
            return "Proxy response: "+line+"\nA 200 response means CONNECT was accepted; authentication may be required for other destinations."; }
    }
    private String testSocks5() throws Exception {
        try(Socket s=proxySocket()) { OutputStream o=s.getOutputStream(); InputStream in=s.getInputStream(); o.write(new byte[]{5,1,0}); o.flush();
            int v=in.read(), m=in.read(); return "SOCKS5 greeting: version="+v+", selected_auth_method="+m+(v==5?"\nSOCKS5 server responded.":"\nNot a SOCKS5 service."); }
    }
    private String testWebSocket() throws Exception {
        try(Socket s=proxySocket()) { String key="dGhlIHNhbXBsZSBub25jZQ==";
            String req="GET / HTTP/1.1\r\nHost: "+proxyHost()+"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+key+"\r\nSec-WebSocket-Version: 13\r\n\r\n";
            s.getOutputStream().write(req.getBytes(StandardCharsets.US_ASCII)); s.getOutputStream().flush();
            BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.US_ASCII));
            return "WebSocket upgrade response: "+in.readLine()+"\n101 indicates the server accepted a WebSocket upgrade."; }
    }
    private void pickConfig() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_CONFIG); }
    @Override protected void onActivityResult(int req,int res,Intent data) { super.onActivityResult(req,res,data); if(req==PICK_CONFIG && res==RESULT_OK && data!=null) {
        try(InputStream in=getContentResolver().openInputStream(data.getData())) { ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n,total=0; while((n=in.read(buf))>0 && total<1024*1024){b.write(buf,0,n);total+=n;}
            String cfg=new String(b.toByteArray(),StandardCharsets.UTF_8); String lower=cfg.toLowerCase(); StringBuilder r=new StringBuilder("Profile format: ");
            if(lower.contains("[interface]") && lower.contains("[peer]")) r.append("WireGuard\n").append("Interface/Peer sections: present\n").append("PrivateKey field: ").append(lower.contains("privatekey")?"present (not displayed)":"missing").append("\nEndpoint field: ").append(lower.contains("endpoint")?"present":"missing");
            else if(lower.contains("client") && (lower.contains("remote ") || lower.contains("<connection>"))) r.append("OpenVPN\nClient directive: present\nRemote endpoint: ").append(lower.contains("remote ")?"present":"not detected");
            else r.append("Unknown/unsupported profile. Expected .conf (WireGuard) or .ovpn (OpenVPN).");
            r.append("\n\nSecurity: profile contents and private keys are not shown or uploaded. This app validates profile structure only; use the official client to connect."); output.setText(r.toString());
        } catch(Exception e) { output.setText("Could not read profile: "+e.getMessage()); }
    }}
    @Override protected void onDestroy() { super.onDestroy(); pool.shutdownNow(); }
}
